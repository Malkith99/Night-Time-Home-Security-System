# NodeMCU ESP8266 Webserver Access Point Mode
Let's build  Webserver on NodeMCU ESP8266 in Soft Access Point Mode. We've connected Red LED to **D4**. The final circuit connection will look as it shown in picture below

![alt text](https://github.com/binaryupdates/Blynk-NodeMCU-ESP8266/blob/main/LED%20with%20NodeMCU%20ESP8266.jpg)
